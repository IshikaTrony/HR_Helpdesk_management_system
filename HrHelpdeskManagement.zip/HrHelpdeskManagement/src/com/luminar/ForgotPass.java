package com.luminar;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/forgotpass")
public class ForgotPass extends HttpServlet {

    private static final long serialVersionUID = 1L;

    public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {

        // Retrieve form parameters
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        // Perform database validation
        boolean isValidUser = validateUser(username);

        if (isValidUser) {
            Connection conn = null;
            PreparedStatement pstmt = null;
            String driver="ishi#mysql08";
            String url="jdbc:mysql://localhost:3306/hr_helpdesk";
            String root="root";
            String pass="ishi#mysql08";
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection(url,root,pass);
                String sql = "UPDATE employee SET emp_password = ? WHERE emp_username = ?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, password);
                pstmt.setString(2, username);

                pstmt.executeUpdate();
                res.sendRedirect("home.html");
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                // Close JDBC objects
                try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
                try { if (conn != null) conn.close(); } catch (Exception e) {}
            }
        } else {
            res.sendRedirect("forgetpassword.html");
        }

    }

    public boolean validateUser(String username) {
        boolean isValidUser = false;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String url="jdbc:mysql://localhost:3306/hr_helpdesk";
        String root="root";
        String password="ishi#mysql08";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(url,root,password);

            String sql = "SELECT * FROM employee WHERE emp_username = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);

            rs = pstmt.executeQuery();

            if (rs.next()) {
                isValidUser = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close JDBC objects
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }

        return isValidUser;
    }
}
