package com.luminar;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/updateuser")
	public class AdminUpdateUser extends HttpServlet {
		private static final long serialVersionUID = 1L;
		final String driver = "com.mysql.cj.jdbc.Driver";
		final String url = "jdbc:mysql://localhost:3306/hr_helpdesk";
		final String user = "root";
		final String password = "ishi#mysql08";

		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;

		RequestDispatcher dis = null;
		String userName = "";
		String userRole = "";
		String userId = "";

		public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			try {
				
				HttpSession session = request.getSession(false);
				/*String name = (String) session.getAttribute("user");
				String adminID = (String) session.getAttribute("userId");
				*/
				String userperID = request.getParameter("userperID");
				String uname = request.getParameter("uname");
				String uemailId = request.getParameter("uemailId");
				
				String uusername = request.getParameter("uusername");			
				String upass = request.getParameter("upassword");
				String role = request.getParameter("role");

				Class.forName(driver);
				con=DriverManager.getConnection(url,user,password);
						
				
						
				String sql="UPDATE employee set emp_name=?,emp_username=?,emp_password=?,emp_mail=?,emp_role=? where emp_id="+userperID;
						
				
				pst=con.prepareStatement(sql);
				
				pst.setString(1, uname);
				pst.setString(2, uusername);
				pst.setString(3, upass);
				pst.setString(4, uemailId);
				pst.setString(5, role);
				
				//to delete
				System.out.println(sql);
		        
				pst.executeUpdate();
				
				response.sendRedirect("viewusers");
				

			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}



